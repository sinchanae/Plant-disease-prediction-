
PlantCareX - AI Powered Leaf Disease Diagnosis Framework

Steps:
1. Put dataset into 'dataset/' folder with subfolders for each class.
2. Install dependencies:
   pip install -r requirements.txt
3. Train model:
   python train.py
4. Run app:
   python app.py
5. Open browser:
   http://127.0.0.1:5000
