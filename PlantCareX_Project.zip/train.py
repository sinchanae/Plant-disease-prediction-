
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras import layers, models

gen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

train = gen.flow_from_directory('dataset', target_size=(128,128),
                                batch_size=32, class_mode='categorical',
                                subset='training')

val = gen.flow_from_directory('dataset', target_size=(128,128),
                              batch_size=32, class_mode='categorical',
                              subset='validation')

model = models.Sequential([
    layers.Conv2D(32,(3,3),activation='relu',input_shape=(128,128,3)),
    layers.MaxPooling2D(2,2),
    layers.Conv2D(64,(3,3),activation='relu'),
    layers.MaxPooling2D(2,2),
    layers.Conv2D(128,(3,3),activation='relu'),
    layers.MaxPooling2D(2,2),
    layers.Flatten(),
    layers.Dense(128,activation='relu'),
    layers.Dense(train.num_classes,activation='softmax')
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.fit(train, validation_data=val, epochs=10)

model.save('model/disease_model.h5')
