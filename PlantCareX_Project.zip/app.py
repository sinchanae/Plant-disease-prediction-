
from flask import Flask, render_template, request
import numpy as np
import os
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image

app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads"
model = load_model("model/disease_model.h5")

classes = ['Healthy', 'Early Blight', 'Late Blight']

solutions = {
    'Healthy': 'No disease detected. Maintain regular irrigation.',
    'Early Blight': 'Spray Mancozeb or Copper fungicide every 7 days.',
    'Late Blight': 'Use Chlorothalonil fungicide and remove infected leaves.'
}

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    file = request.files['file']
    path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(path)

    img = image.load_img(path, target_size=(128,128))
    img = image.img_to_array(img)/255.0
    img = np.expand_dims(img, axis=0)

    pred = model.predict(img)
    result = classes[np.argmax(pred)]
    remedy = solutions[result]

    return render_template("result.html", result=result, remedy=remedy, img=path)

if __name__ == "__main__":
    app.run(debug=True)
